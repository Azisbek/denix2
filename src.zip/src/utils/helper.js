export const SECRET_KEY = 'AIzaSyCZv1tISmQoS2y9axiw3drBXL2DFa1sMcQ'
