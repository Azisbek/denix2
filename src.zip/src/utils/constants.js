export const BASE_URL = 'https://tirewordreact-default-rtdb.firebaseio.com'

// export const BASE_URL =
//    'https://project1-7250d-default-rtdb.asia-southeast1.firebasedatabase.app'

export const SIGNUP =
   'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key='

export const SIGNIN =
   'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key='
